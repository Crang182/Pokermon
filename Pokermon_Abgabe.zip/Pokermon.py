import tkinter as tk
from tkinter import PhotoImage, ttk
from PIL import Image, ImageTk
from random import *
import time
import os
from IPython.display import clear_output
import tot
import win

#Pillowpackage muss installiert werden

def Gegner_attacke():
    
    #Zufallszahl um Gegnerattacken abzuwechseln
    x = randint(1,4)
    
    if x <= 3:
        Mogelbaum.attacke1()
    if x == 4:
        Mogelbaum.attacke2()
        
    
def bisa_kampf():
    window.destroy()
    
    def hp_update():
        label_hp.configure(text=Option1.hp)
        label_hp_gegner.configure(text=Gegner3.hp)
        
        if Option1.hp <= 500:
            label_hp.configure(bg="orange")
        else:
            label_hp.configure(bg="green")
        
    
    def angreifen_animation():
        
        frameCnt = 40
        frames = [PhotoImage(file="rankenhieb.gif",format = "gif -index %i" %(i)) for i in range(frameCnt)]

        def update(ind):

            frame = frames[ind]
            ind += 1
            if ind == frameCnt:
                ind = 0
                bisa_inkampf.configure(image=frames[0])
                return
            bisa_inkampf.configure(image=frame)
            kampf.after(30, update, ind)
        kampf.after(0, update, 0)
          
    def gegner_animation():
        frameCnt = 8
        frames = [PhotoImage(file="Mogel_kauz.gif",format = "gif -index %i" %(i)) for i in range(frameCnt)]

        def update(ind):

            frame = frames[ind]
            ind += 1
            if ind == frameCnt:
                ind = 0
                mogel_inkampf.configure(image=frames[0])
                return
            mogel_inkampf.configure(image=frame)
            kampf.after(100, update, ind)
        kampf.after(0, update, 0)
    
    kampf = tk.Tk()

    #Fenster definieren
    kampf.geometry("930x500")
    kampf.minsize(width=930, height=500)
    
    kampf.title("Pokermon")
    
    #Labels für HP
    label_hp = tk.Label(kampf, text=Option1.hp,bg="green")
    label_hp.pack(side="top", fill= "x")
    
    label_hp_gegner = tk.Label(kampf, text=Gegner3.hp,bg="yellow")
    label_hp_gegner.pack(side="top",fill= "x")
    
    #Pokermons im kampf
    image = Image.open("Mogel_kauz.gif").resize((200,200))
    photo4 = ImageTk.PhotoImage(image)

    image = Image.open("rankenhieb.gif").resize((200,200))
    photo5 = ImageTk.PhotoImage(image)
    
    bisa_inkampf = ttk.Button(kampf)                 
    bisa_inkampf.configure(image=photo5)
    bisa_inkampf.pack(side="left") 

    mogel_inkampf = ttk.Button(kampf)                 
    mogel_inkampf.configure(image=photo4)
    mogel_inkampf.pack(side="right") 
    
    
    #Buttons für Attacken
    angriff1 = ttk.Button(kampf, text="Rankenhieb", command=lambda: [Bisakack.attacke1(), hp_update(), angreifen_animation(), gegner_animation()]) #hp_update(label_hp,label_hp_gegner)
    angriff1.pack(side="bottom")
    
    angriff2 = ttk.Button(kampf, text="Panzer",command=lambda: [Bisakack.attacke2(), hp_update(), gegner_animation()]) #hp_update(label_hp,label_hp_gegner)
    angriff2.pack(side="bottom")

    kampf.mainloop()
    
def glut_kampf():
    window.destroy()
    
    def hp_update():
        
        label_hp.configure(text=Option2.hp)
        label_hp_gegner.configure(text=Gegner3.hp)
        
        if Option2.hp <= 500:
            label_hp.configure(bg="orange")
        else:
            label_hp.configure(bg="green")
        
    def angreifen_animation():
        
        frameCnt = 70
        frames = [PhotoImage(file="superblast.gif",format = "gif -index %i" %(i)) for i in range(frameCnt)]

        def update(ind):

            frame = frames[ind]
            ind += 1
            if ind == frameCnt:
                ind = 0
                glut_inkampf.configure(image=frames[0])
                return
            glut_inkampf.configure(image=frame)
            kampf.after(60, update, ind)
        kampf.after(0, update, 0)
          
    def gegner_animation():
        frameCnt = 8
        frames = [PhotoImage(file="Mogel_kauz.gif",format = "gif -index %i" %(i)) for i in range(frameCnt)]

        def update(ind):

            frame = frames[ind]
            ind += 1
            if ind == frameCnt:
                ind = 0
                mogel_inkampf.configure(image=frames[0])
                return
            mogel_inkampf.configure(image=frame)
            kampf.after(100, update, ind)
        kampf.after(0, update, 0)
    
    kampf = tk.Tk()

    #Fenster definieren
    kampf.geometry("930x500")
    kampf.minsize(width=930, height=500)
    
    kampf.title("Pokermon")
    
    #Labels für HP
    label_hp = tk.Label(kampf, text=Option2.hp,bg="green")
    label_hp.pack(side="top", fill= "x")
    
    label_hp_gegner = tk.Label(kampf, text=Gegner3.hp,bg="yellow")
    label_hp_gegner.pack(side="top",fill= "x")
    
    #Pokermons im kampf
    image = Image.open("Mogel_kauz.gif").resize((200,200))
    photo4 = ImageTk.PhotoImage(image)

    image = Image.open("006.png").resize((200,200))
    photo5 = ImageTk.PhotoImage(image)
    
    glut_inkampf = ttk.Button(kampf)                 
    glut_inkampf.configure(image=photo5)
    glut_inkampf.pack(side="left") 

    mogel_inkampf = ttk.Button(kampf)                 
    mogel_inkampf.configure(image=photo4)
    mogel_inkampf.pack(side="right") 
    
    #Buttons für Attacken
    angriff1 = ttk.Button(kampf, text="Pew", command=lambda: [angreifen_animation(), hp_update(), Glutkek.attacke1(), gegner_animation()]) #hp_update(label_hp,label_hp_gegner)
    angriff1.pack(side="bottom")
    
    angriff2 = ttk.Button(kampf, text="Glutstau",command=lambda: [Glutkek.attacke2(), hp_update(), gegner_animation()]) #hp_update(label_hp,label_hp_gegner)
    angriff2.pack(side="bottom")

    kampf.mainloop()

def showstats1():
    Option1.infos_ausgeben()
    
def showstats2():
    Option2.infos_ausgeben()
    
    
class Pokermon:

    #Kontruktor Elternklasse
    def __init__(self, name, hp, type, attacken_info1, attacken_info2):
        self.name = name
        self.hp = hp
        self.type = type
        self.attacken_info1 = attacken_info1
        self.attacken_info2 = attacken_info2

    def infos_ausgeben(self):
        print ("Name: ", self.name , " Type: ", self.type, " HP: ", self.hp, " ", self.attacken_info1, " ", self.attacken_info2)

    def attacke1():
        pass
    def attacke2():
        pass
    def attacke3():
        pass

class Bisakack(Pokermon):

    #Bisakack Attacken
    def attacke1():
        clear_output() 
        Gegner3.hp = Gegner3.hp - 1000
        print("Gegner hp: ", Gegner3.hp)
                                                                          
        if Gegner3.hp > 0:
            Gegner_attacke()
            if Option1.hp <= 0:
                tot.tot()
        elif Gegner3.hp <= 0:
            win.win()

    def attacke2():
        clear_output()
        Option1.hp = Option1.hp + 250
        print("deine HP betragen nun: ", Option1.hp)
        
        if Gegner3.hp > 0:
            Gegner_attacke()
            if Option1.hp <= 0:
                tot.tot()
        elif Gegner3.hp <= 0:
            win.win()


class Glutkek(Pokermon):
    
    #Attacken von Glutkek
    def attacke1():
        clear_output()
        if Option2.hp > 500:
            print("Er kann diese Attacke noch nicht einsetzen... ")
        else:
            Gegner3.hp = 0
            print("Gegner hp: ", Gegner3.hp)    
                                                                          
        if Gegner3.hp > 0:
            Gegner_attacke()
            if Option2.hp <= 0:
                tot.tot()
        elif Gegner3.hp <= 0:
            win.win()

    def attacke2():
        
        clear_output()
        print("Glutkek sammelt sich: deine HP betragen ", Option1.hp)
        if Gegner3.hp > 0:
            Gegner_attacke()
            if Option1.hp <= 0:
                tot.tot()
        elif Gegner3.hp <= 0:
            win.win()

class Mogelbaum(Pokermon):   
    
    #Attacken von Mogelbaum
    def attacke1():
        Option1.hp = Option1.hp - 220
        Option2.hp = Option2.hp - 220
        print("Mogelbaum setzt holzkopf ein. Dein leben wurde um 220 reduziert")

    def attacke2():
        Gegner3.hp = Gegner3.hp + 800
        print("Mogelbaum mogelt und schläfert dich ein, er regeneriert: 800Hp und ist nochmal dran")
        Gegner_attacke()
        

#if __name__ == "__main__":   #alles ausführen in py datei

#unsere Auswahlpokermons initialisieren
Option1 = Bisakack("Bisakack", 2000, "Pflanze", "Rankenhieb verursacht 1000 Schaden", "Panzer Heilt um 300")
Option2 = Glutkek("Glutkek", 2000, "Feuer", "Pew zerstört alles, ist jedoch nur unter gewissen Voraussetzungen nutzbar..", "Glutstau sammelt sein Feuer an")

#Gegnerpokermon initialisieren
Gegner3 = Mogelbaum("Mogelbaum", 8000, "Pflanze", "Rankenhieb verursacht 500 Schaden", "Panzer Heilt um 800 (3x einsetzbar)" )

#Auswahl der Pokermons als Fenster

#eigentliches Fenster
window = tk.Tk()

#Fenstergröße definieren
window.geometry("930x500")
window.minsize(width=930, height=500)

#Titel
window.title("Pokermon")

#Windgets in Fenster

label1 = tk.Label(window, text="Wähle dein Pokermon!")
label1.pack(side="top")

#Buttons für Stats

choose_bisa = ttk.Button(window)
choose_bisa.configure(text="infos Bisakack",command=showstats1)
choose_bisa.pack(side="bottom")

choose_glut = ttk.Button(window)
choose_glut.configure(text="infos Glutkek",command=showstats2)
choose_glut.pack(side="bottom") 

# Bilder initialisieren
image = Image.open("Bisakack.png").resize((300,300)) 
photo1 = ImageTk.PhotoImage(image)

image = Image.open("Glutkek.png").resize((300,300)) 
photo2 = ImageTk.PhotoImage(image)

#Pokeauswahl
choose_bisa = ttk.Button(window)                 
choose_bisa.configure(image=photo1, command=bisa_kampf,)
choose_bisa.pack(side="left") 

choose_glut = ttk.Button(window)
choose_glut.configure(image=photo2, command=glut_kampf)
choose_glut.pack(side="right") 

#Fenster bleibt und prüft auf interaktionen
window.mainloop()