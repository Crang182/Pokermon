import tkinter as tk

def win():
    win = tk.Tk()
    win.geometry("400x50")
    win.title("Pokermon")
    
    label_tot = tk.Label(win, text="         Gewonnen, du hast den Baum besiegt!")
    label_tot.pack(side="left",fill= "x")
    
    win.mainloop()