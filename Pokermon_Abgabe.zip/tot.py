import tkinter as tk

def tot():
    tot = tk.Tk()
    tot.geometry("400x50")
    tot.title("Pokermon")
    
    label_tot = tk.Label(tot, text="                           Verloren, weil du bist tot ;-(")
    label_tot.pack(side="left",fill= "x")
    
    tot.mainloop()